"""
Script to fix the duplicated index.html and add PWA support
"""
import os
import re

def fix_html():
    """Fix the duplicated HTML file and add PWA meta tags"""
    
    html_path = os.path.join('templates', 'index.html')
    
    # Read the current file
    with open(html_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check if file starts with proper DOCTYPE
    if not content.strip().startswith('<!DOCTYPE html>'):
        print("⚠ HTML file is corrupted (missing DOCTYPE)")
        print("Creating a clean version...")
        
        # Find the first occurrence of <div class="app-container">
        app_container_start = content.find('<div class="app-container">')
        
        if app_container_start == -1:
            print("✗ Could not find app-container div")
            return False
        
        # Extract the body content (from app-container to the end)
        body_content = content[app_container_start:]
        
        # Find where the script starts
        script_start = body_content.find('<script>')
        if script_start == -1:
            print("✗ Could not find script tag")
            return False
        
        # Split into HTML and script
        html_body = body_content[:script_start]
        script_content = body_content[script_start:]
        
        # Remove duplicate functions in script
        # Keep only one copy of each function
        script_content = remove_duplicate_functions(script_content)
        
        # Create the complete HTML
        complete_html = f'''<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jarama Music</title>
    
    <!-- PWA Meta Tags -->
    <meta name="description" content="Your personal music streaming and download platform">
    <meta name="theme-color" content="#8b5cf6">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="Jarama Music">
    
    <!-- PWA Manifest -->
    <link rel="manifest" href="{{{{ url_for('static', filename='manifest.json') }}}}">
    
    <!-- Icons for iOS -->
    <link rel="apple-touch-icon" sizes="72x72" href="{{{{ url_for('static', filename='icons/icon-72x72.png') }}}}">
    <link rel="apple-touch-icon" sizes="96x96" href="{{{{ url_for('static', filename='icons/icon-96x96.png') }}}}">
    <link rel="apple-touch-icon" sizes="128x128" href="{{{{ url_for('static', filename='icons/icon-128x128.png') }}}}">
    <link rel="apple-touch-icon" sizes="144x144" href="{{{{ url_for('static', filename='icons/icon-144x144.png') }}}}">
    <link rel="apple-touch-icon" sizes="152x152" href="{{{{ url_for('static', filename='icons/icon-152x152.png') }}}}">
    <link rel="apple-touch-icon" sizes="192x192" href="{{{{ url_for('static', filename='icons/icon-192x192.png') }}}}">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" sizes="32x32" href="{{{{ url_for('static', filename='icons/icon-72x72.png') }}}}">
    <link rel="icon" type="image/png" sizes="16x16" href="{{{{ url_for('static', filename='icons/icon-72x72.png') }}}}">
    
    <!-- Fonts and Styles -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{{{ url_for('static', filename='style.css') }}}}">
</head>

<body>

    <div class="mobile-overlay" id="mobile-overlay" onclick="toggleSidebar()"></div>

    {html_body}

    {script_content}
</body>

</html>'''
        
        # Save the fixed file
        with open(html_path, 'w', encoding='utf-8') as f:
            f.write(complete_html)
        
        print("✓ HTML file fixed successfully!")
        return True
    
    else:
        print("✓ HTML file looks good, just adding PWA support...")
        # File is OK, just add PWA meta tags if missing
        if '<link rel="manifest"' not in content:
            # Add PWA meta tags after <title>
            pwa_meta = '''
    
    <!-- PWA Meta Tags -->
    <meta name="description" content="Your personal music streaming and download platform">
    <meta name="theme-color" content="#8b5cf6">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="Jarama Music">
    
    <!-- PWA Manifest -->
    <link rel="manifest" href="{{ url_for('static', filename='manifest.json') }}">
    
    <!-- Icons for iOS -->
    <link rel="apple-touch-icon" sizes="192x192" href="{{ url_for('static', filename='icons/icon-192x192.png') }}">
'''
            content = content.replace('</title>', '</title>' + pwa_meta)
        
        # Add Service Worker registration if missing
        if 'serviceWorker' not in content:
            sw_script = '''
    // PWA - Service Worker Registration
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('/static/sw.js')
                .then((registration) => {
                    console.log('✓ Service Worker registered:', registration.scope);
                })
                .catch((error) => {
                    console.log('✗ Service Worker registration failed:', error);
                });
        });
    }
'''
            # Add before closing script tag
            content = content.replace('loadLibrary();\n    </script>', f'loadLibrary();\n{sw_script}    </script>')
        
        # Save
        with open(html_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        print("✓ PWA support added!")
        return True

def remove_duplicate_functions(script):
    """Remove duplicate function declarations"""
    # This is a simple approach - keeps first occurrence of each function
    lines = script.split('\n')
    seen_functions = set()
    result_lines = []
    skip_until = None
    
    for i, line in enumerate(lines):
        # Check if this is a function declaration
        func_match = re.match(r'\s*function\s+(\w+)\s*\(', line)
        const_func_match = re.match(r'\s*const\s+(\w+)\s*=', line)
        
        if func_match:
            func_name = func_match.group(1)
            if func_name in seen_functions:
                # Skip this function
                skip_until = find_function_end(lines, i)
                continue
            else:
                seen_functions.add(func_name)
        elif const_func_match:
            var_name = const_func_match.group(1)
            if var_name in seen_functions:
                continue
            else:
                seen_functions.add(var_name)
        
        if skip_until is not None and i < skip_until:
            continue
        else:
            skip_until = None
        
        result_lines.append(line)
    
    return '\n'.join(result_lines)

def find_function_end(lines, start):
    """Find the end of a function declaration"""
    brace_count = 0
    for i in range(start, len(lines)):
        brace_count += lines[i].count('{')
        brace_count -= lines[i].count('}')
        if brace_count == 0 and i > start:
            return i + 1
    return len(lines)

if __name__ == "__main__":
    print("=" * 50)
    print("Jarama Music - HTML Fixer")
    print("=" * 50)
    print()
    
    if fix_html():
        print()
        print("✓ All done! Your HTML is now fixed with PWA support.")
        print()
        print("Next steps:")
        print("1. Run: python generate_icons.py")
        print("2. Restart your Flask server")
        print("3. Open http://localhost:5000 in Chrome")
        print("4. Check DevTools > Application > Manifest")
    else:
        print()
        print("✗ Could not fix HTML automatically.")
        print("Please check PWA_SETUP_GUIDE.md for manual instructions.")
