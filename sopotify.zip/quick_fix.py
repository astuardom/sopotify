"""
Quick fix for the fetch syntax error
"""
import re

html_path = 'templates/index.html'

with open(html_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Fix the broken fetch call
# Find the pattern: try {\n                method: 'POST',
# Replace with: try {\n            const response = await fetch('/download', {\n                method: 'POST',

pattern = r"try \{\s+method: 'POST',"
replacement = "try {\n            const response = await fetch('/download', {\n                method: 'POST',"

content = re.sub(pattern, replacement, content)

with open(html_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("✓ Fixed fetch syntax error!")
